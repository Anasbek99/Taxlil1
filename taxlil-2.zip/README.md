# Svecha Tahlilchisi (Pocket Option uchun Android loyiha)

Ushbu loyiha Pocket Option (yoki boshqa grafik ilova) ustida suzuvchi ramka ochib, ekran tasviridan yashil va qizil svechalarni sanab, grafikni avtomatik orqaga surib chiqadi.

## GitHub Actions orqali APK olish

1. GitHub'da yangi repository yarating va arxivdagi barcha fayllarni (`.github` papkasi bilan birga) yuklang.
2. **Actions** bo'limidan **Build Android APK** tugagach, **Artifacts** ichidan `pocket-candle-scanner-apk` (`app-debug.apk`) ni yuklab oling.

## Muhim eslatma

Ilova svechalarni ekran piksel rangi orqali taxminiy sanaydi. Aniqlik uchun grafikni o'rtacha masshtabda ushlang va boshqa yashil/qizil indikatorlarni o'chirib qo'ying.
