package uz.avazbek.candlescanner

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvAccessStatus: TextView
    private lateinit var tvCaptureStatus: TextView
    private lateinit var etTargetCount: EditText
    private lateinit var etSwipeDelay: EditText

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, "Ekran tasviri tayyor!", Toast.LENGTH_SHORT).show()
            updateStatusTexts()
        } else {
            Toast.makeText(this, "Ruxsat berilmadi", Toast.LENGTH_SHORT).show()
        }
    }

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            requestMediaProjection()
        } else {
            Toast.makeText(this, "Bildirishnoma ruxsati kerak", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvAccessStatus = findViewById(R.id.tvAccessStatus)
        tvCaptureStatus = findViewById(R.id.tvCaptureStatus)
        etTargetCount = findViewById(R.id.etTargetCount)
        etSwipeDelay = findViewById(R.id.etSwipeDelay)

        val prefs = getSharedPreferences(AutoSwipeAccessibilityService.PREFS_NAME, Context.MODE_PRIVATE)
        etTargetCount.setText(prefs.getInt(AutoSwipeAccessibilityService.KEY_TARGET_COUNT, 50).toString())
        etSwipeDelay.setText(prefs.getLong(AutoSwipeAccessibilityService.KEY_SWIPE_DELAY_MS, 900L).toString())

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnScreenCapture).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                requestMediaProjection()
            }
        }

        findViewById<Button>(R.id.btnSaveSettings).setOnClickListener {
            val count = (etTargetCount.text.toString().trim().toIntOrNull() ?: 50).coerceIn(1, 5000)
            val delay = (etSwipeDelay.text.toString().trim().toLongOrNull() ?: 900L).coerceAtLeast(300L)
            etTargetCount.setText(count.toString())
            etSwipeDelay.setText(delay.toString())
            prefs.edit()
                .putInt(AutoSwipeAccessibilityService.KEY_TARGET_COUNT, count)
                .putLong(AutoSwipeAccessibilityService.KEY_SWIPE_DELAY_MS, delay)
                .apply()
            Toast.makeText(this, "Saqlandi: $count ta svecha, $delay ms", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnShowOverlay).setOnClickListener {
            val service = AutoSwipeAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Avval Maxsus imkoniyatlar ruxsatini yoqing", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                service.showOverlay()
            }
        }

        findViewById<Button>(R.id.btnHideOverlay).setOnClickListener {
            AutoSwipeAccessibilityService.instance?.hideOverlay()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusTexts()
    }

    private fun requestMediaProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun updateStatusTexts() {
        if (AutoSwipeAccessibilityService.instance != null) {
            tvAccessStatus.text = "Maxsus imkoniyatlar: Yoqilgan"
            tvAccessStatus.setTextColor(Color.parseColor("#34D399"))
        } else {
            tvAccessStatus.text = "Maxsus imkoniyatlar: O'chirilgan"
            tvAccessStatus.setTextColor(Color.parseColor("#FB7185"))
        }

        if (ScreenCaptureService.instance != null) {
            tvCaptureStatus.text = "Ekran tasviri: Tayyor"
            tvCaptureStatus.setTextColor(Color.parseColor("#34D399"))
        } else {
            tvCaptureStatus.text = "Ekran tasviri: Ruxsat berilmagan"
            tvCaptureStatus.setTextColor(Color.parseColor("#FB7185"))
        }
    }
}
