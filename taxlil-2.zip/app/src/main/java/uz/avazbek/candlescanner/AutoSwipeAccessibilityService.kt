package uz.avazbek.candlescanner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class AutoSwipeAccessibilityService : AccessibilityService() {

    companion object {
        const val PREFS_NAME = "candle_scanner_prefs"
        const val KEY_TARGET_COUNT = "target_count"
        const val KEY_SWIPE_DELAY_MS = "swipe_delay_ms"
        var instance: AutoSwipeAccessibilityService? = null
            private set
    }

    private lateinit var windowManager: WindowManager
    private var roiBoxView: View? = null
    private var roiBoxParams: WindowManager.LayoutParams? = null
    private var controlBarView: LinearLayout? = null
    private var tvStats: TextView? = null
    private var btnPlayPause: Button? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var targetCount = 50
    private var totalCounted = 0
    private var greenTotal = 0
    private var redTotal = 0

    private val scanStepRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return

            val capture = ScreenCaptureService.instance
            val box = roiBoxView
            if (capture == null || box == null) {
                stopScanning("Avval ekran tasviriga ruxsat bering")
                return
            }

            val loc = IntArray(2)
            box.getLocationOnScreen(loc)
            val roi = Rect(loc[0], loc[1], loc[0] + box.width, loc[1] + box.height)

            val (green, red) = capture.countCandlesInRegion(roi)
            val remaining = (targetCount - totalCounted).coerceAtLeast(0)
            val batchTotal = green + red

            if (batchTotal > 0) {
                if (batchTotal <= remaining) {
                    greenTotal += green
                    redTotal += red
                    totalCounted += batchTotal
                } else {
                    val ratioGreen = (green.toFloat() / batchTotal * remaining).toInt()
                    val ratioRed = remaining - ratioGreen
                    greenTotal += ratioGreen
                    redTotal += ratioRed
                    totalCounted += remaining
                }
            }

            updateStatsText()

            if (totalCounted >= targetCount) {
                stopScanning("Tugadi: $totalCounted ta svecha sanaldi")
                return
            }

            // Swipe left-to-right inside the ROI box to scroll chart history backward
            performBackwardSwipe(roi)

            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val delay = prefs.getLong(KEY_SWIPE_DELAY_MS, 900L).coerceAtLeast(300L)
            handler.postDelayed(this, delay)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopScanning(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
        if (instance == this) instance = null
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showOverlay() {
        if (roiBoxView != null) return

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        targetCount = prefs.getInt(KEY_TARGET_COUNT, 50)

        val metrics = resources.displayMetrics
        val density = metrics.density

        // 1. Semi-transparent Scan Frame
        val boxW = (metrics.widthPixels * 0.72f).toInt()
        val boxH = (metrics.heightPixels * 0.30f).toInt()
        val box = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = 12 * density
                setColor(Color.parseColor("#1410B981"))
                setStroke((2 * density).toInt(), Color.parseColor("#10B981"))
            }
        }
        val boxParams = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (metrics.widthPixels - boxW) / 2
            y = (metrics.heightPixels - boxH) / 2
        }
        makeDraggable(box, boxParams)
        windowManager.addView(box, boxParams)
        roiBoxView = box
        roiBoxParams = boxParams

        // 2. Floating Control Bar + Stats
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * density).toInt(), (6 * density).toInt(), (12 * density).toInt(), (6 * density).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 24 * density
                setColor(Color.parseColor("#EB0F172A"))
                setStroke((1 * density).toInt(), Color.parseColor("#475569"))
            }
        }

        val stats = TextView(this).apply {
            text = "0/$targetCount | 🟢0 🔴0"
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(0, 0, (8 * density).toInt(), 0)
        }

        val playBtn = Button(this).apply {
            text = "▶"
            textSize = 15f
            setTextColor(Color.parseColor("#10B981"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                if (isRunning) stopScanning(null) else startScanning()
            }
        }

        val closeBtn = Button(this).apply {
            text = "✕"
            textSize = 15f
            setTextColor(Color.parseColor("#FB7185"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                hideOverlay()
            }
        }

        bar.addView(stats)
        bar.addView(playBtn)
        bar.addView(closeBtn)

        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (24 * density).toInt()
            y = (80 * density).toInt()
        }

        makeDraggable(bar, barParams)
        windowManager.addView(bar, barParams)
        controlBarView = bar
        tvStats = stats
        btnPlayPause = playBtn
    }

    fun hideOverlay() {
        stopScanning(null)
        roiBoxView?.let { runCatching { windowManager.removeView(it) } }
        controlBarView?.let { runCatching { windowManager.removeView(it) } }
        roiBoxView = null
        roiBoxParams = null
        controlBarView = null
        tvStats = null
        btnPlayPause = null
    }

    private fun startScanning() {
        if (ScreenCaptureService.instance == null) {
            Toast.makeText(this, "Avval ilovada Ekran tasviriga ruxsat bering", Toast.LENGTH_LONG).show()
            return
        }
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        targetCount = prefs.getInt(KEY_TARGET_COUNT, 50)
        totalCounted = 0
        greenTotal = 0
        redTotal = 0
        updateStatsText()

        setBoxTouchable(false)
        isRunning = true
        btnPlayPause?.text = "⏸"
        btnPlayPause?.setTextColor(Color.parseColor("#FBBF24"))
        handler.post(scanStepRunnable)
    }

    private fun setBoxTouchable(touchable: Boolean) {
        val box = roiBoxView ?: return
        val params = roiBoxParams ?: return
        params.flags = if (touchable) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        runCatching { windowManager.updateViewLayout(box, params) }
    }

    private fun stopScanning(message: String?) {
        isRunning = false
        handler.removeCallbacks(scanStepRunnable)
        setBoxTouchable(true)
        btnPlayPause?.text = "▶"
        btnPlayPause?.setTextColor(Color.parseColor("#10B981"))
        if (message != null) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun updateStatsText() {
        tvStats?.text = "$totalCounted/$targetCount | 🟢$greenTotal 🔴$redTotal"
    }

    private fun performBackwardSwipe(roi: Rect) {
        val startX = roi.left + roi.width() * 0.12f
        val endX = roi.left + roi.width() * 0.88f
        val y = roi.centerY().toFloat()

        val path = Path().apply {
            moveTo(startX, y)
            lineTo(endX, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 450L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }
}
