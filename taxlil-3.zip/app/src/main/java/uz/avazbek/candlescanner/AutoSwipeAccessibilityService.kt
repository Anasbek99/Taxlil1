package uz.avazbek.candlescanner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class AutoSwipeAccessibilityService : AccessibilityService() {

    companion object {
        const val PREFS_NAME = "candle_scanner_prefs"
        const val KEY_MODE = "scan_mode"
        const val MODE_HISTORY = "history"
        const val MODE_REALTIME = "realtime"
        const val KEY_TARGET_COUNT = "target_count"
        const val KEY_ZEBRA_THRESHOLD = "zebra_threshold"
        const val KEY_SWIPE_DELAY_MS = "swipe_delay_ms"
        const val KEY_BOT_TOKEN = "bot_token"
        const val KEY_CHAT_ID = "chat_id"

        const val KEY_BOX_X = "box_x"
        const val KEY_BOX_Y = "box_y"
        const val KEY_BOX_W = "box_w"
        const val KEY_BOX_H = "box_h"
        const val KEY_SAVED_RESULTS = "saved_analysis_results"

        var instance: AutoSwipeAccessibilityService? = null
            private set
    }

    private lateinit var windowManager: WindowManager
    private var roiBoxView: View? = null
    private var roiBoxParams: WindowManager.LayoutParams? = null
    private var resizeHandleView: TextView? = null
    private var resizeHandleParams: WindowManager.LayoutParams? = null
    private var controlBarView: LinearLayout? = null
    private var tvStats: TextView? = null
    private var btnPlayPause: Button? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var currentMode = MODE_HISTORY
    private var targetCount = 1440
    private var zebraThreshold = 8

    // History stats
    private var totalCounted = 0
    private var maxZebraFound = 0
    private var maxZebraRepeats = 0
    private var thresholdHits = 0
    private val streakCounts = mutableMapOf<Int, Int>()

    // Real-time stats
    private var currentLiveZebra = 0
    private var alertSentForCurrentStreak = false

    private val loopRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return

            val capture = ScreenCaptureService.instance
            val box = roiBoxView
            if (capture == null || box == null) {
                stopScanning("Avval ekran tasviriga ruxsat bering")
                return
            }

            val loc = IntArray(2)
            box.getLocationOnScreen(loc)
            val roi = Rect(loc[0], loc[1], loc[0] + box.width, loc[1] + box.height)
            val candles = capture.detectCandleSequence(roi)

            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val delay = prefs.getLong(KEY_SWIPE_DELAY_MS, 1000L).coerceAtLeast(300L)

            if (currentMode == MODE_HISTORY) {
                processHistoryFrame(candles, roi)
                if (!isRunning) return
                handler.postDelayed(this, delay)
            } else {
                processRealtimeFrame(candles)
                handler.postDelayed(this, delay.coerceAtLeast(2000L))
            }
        }
    }

    private fun processHistoryFrame(candles: List<Int>, roi: Rect) {
        if (candles.isNotEmpty()) {
            totalCounted += candles.size

            var streak = 1
            for (i in 1 until candles.size) {
                if (candles[i] != candles[i - 1]) {
                    streak++
                } else {
                    recordHistoryStreak(streak)
                    streak = 1
                }
            }
            recordHistoryStreak(streak)
        }

        updateStatsText()

        if (totalCounted >= targetCount) {
            val report = buildHistoryReport()
            saveHistoryReport(report)
            sendTelegramIfConfigured(report)
            stopScanning("Tarix tahlili tugadi ($totalCounted ta svecha)!")
            return
        }

        performBackwardSwipe(roi)
    }

    private fun recordHistoryStreak(streak: Int) {
        if (streak >= 5) {
            streakCounts[streak] = (streakCounts[streak] ?: 0) + 1
        }
        if (streak >= zebraThreshold) {
            thresholdHits++
        }
        if (streak > maxZebraFound) {
            maxZebraFound = streak
            maxZebraRepeats = 1
        } else if (streak == maxZebraFound && streak >= 2) {
            maxZebraRepeats++
        }
    }

    private fun buildHistoryReport(): String {
        val sb = StringBuilder()
        sb.appendLine("📊 Tahlil natijasi ($totalCounted ta svecha)")
        sb.appendLine("Eng katta Zebra: $maxZebraFound ta")
        sb.appendLine()
        if (maxZebraFound < 5) {
            sb.append("5 talik va undan katta Zebra uchramadi.")
        } else {
            for (len in 5..maxZebraFound) {
                val cnt = streakCounts[len] ?: 0
                sb.appendLine("• ${len} talik zebradan keyin buzildi: $cnt marta")
            }
        }
        return sb.toString().trim()
    }

    private fun saveHistoryReport(report: String) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(KEY_SAVED_RESULTS, "[]") ?: "[]"
        val oldArr = try { JSONArray(rawJson) } catch (e: Exception) { JSONArray() }

        val breakdownObj = JSONObject()
        if (maxZebraFound >= 5) {
            for (len in 5..maxZebraFound) {
                breakdownObj.put(len.toString(), streakCounts[len] ?: 0)
            }
        }

        val timeStr = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date())
        val entry = JSONObject().apply {
            put("time", timeStr)
            put("total", totalCounted)
            put("maxZebra", maxZebraFound)
            put("breakdown", breakdownObj)
        }

        val newArr = JSONArray().apply { put(entry) }
        for (i in 0 until minOf(oldArr.length(), 49)) {
            oldArr.optJSONObject(i)?.let { newArr.put(it) }
        }
        prefs.edit().putString(KEY_SAVED_RESULTS, newArr.toString()).apply()
    }

    private fun processRealtimeFrame(candles: List<Int>) {
        if (candles.isEmpty()) {
            currentLiveZebra = 0
            updateStatsText()
            return
        }

        var streak = 1
        for (i in candles.size - 1 downTo 1) {
            if (candles[i] != candles[i - 1]) {
                streak++
            } else {
                break
            }
        }

        currentLiveZebra = streak
        if (streak > maxZebraFound) {
            maxZebraFound = streak
        }

        if (streak >= zebraThreshold) {
            if (!alertSentForCurrentStreak) {
                alertSentForCurrentStreak = true
                val lastColor = if (candles.last() == 1) "YASHIL 🟢" else "QIZIL 🔴"
                val msg = "🦓 ZEBRA SIGNAL! Hozir ketma-ket $streak ta rang almashdi! Oxirgi svecha: $lastColor"
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                sendTelegramIfConfigured(msg)
            }
        } else {
            alertSentForCurrentStreak = false
        }

        updateStatsText()
    }

    private fun sendTelegramIfConfigured(message: String) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val token = prefs.getString(KEY_BOT_TOKEN, "") ?: ""
        val chatId = prefs.getString(KEY_CHAT_ID, "") ?: ""
        if (token.isNotEmpty() && chatId.isNotEmpty()) {
            TelegramNotifier.sendMessage(token, chatId, message)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopScanning(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
        if (instance == this) instance = null
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showOverlay() {
        if (roiBoxView != null) {
            hideOverlay()
        }

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        currentMode = prefs.getString(KEY_MODE, MODE_HISTORY) ?: MODE_HISTORY
        targetCount = prefs.getInt(KEY_TARGET_COUNT, 1440)
        zebraThreshold = prefs.getInt(KEY_ZEBRA_THRESHOLD, 8)

        val metrics = resources.displayMetrics
        val density = metrics.density

        val defaultW = (metrics.widthPixels * 0.84f).toInt()
        val defaultH = (metrics.heightPixels * 0.46f).toInt()
        val defaultX = (metrics.widthPixels * 0.03f).toInt()
        val defaultY = (metrics.heightPixels * 0.22f).toInt()

        val boxW = prefs.getInt(KEY_BOX_W, defaultW).coerceIn((100 * density).toInt(), metrics.widthPixels)
        val boxH = prefs.getInt(KEY_BOX_H, defaultH).coerceIn((80 * density).toInt(), metrics.heightPixels)
        val boxX = prefs.getInt(KEY_BOX_X, defaultX).coerceIn(0, (metrics.widthPixels - 80).coerceAtLeast(0))
        val boxY = prefs.getInt(KEY_BOX_Y, defaultY).coerceIn(0, (metrics.heightPixels - 80).coerceAtLeast(0))

        // 1. Draggable & Resizable Scan Frame
        val box = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = 10 * density
                setColor(Color.parseColor("#0D10B981"))
                setStroke((2 * density).toInt(), Color.parseColor("#10B981"))
            }
        }
        val boxParams = WindowManager.LayoutParams(
            boxW,
            boxH,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = boxX
            y = boxY
        }

        // 2. Corner Resize Handle (bottom-right of box)
        val handleSize = (32 * density).toInt()
        val handle = TextView(this).apply {
            text = "⤡"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#020617"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#10B981"))
            }
        }
        val handleParams = WindowManager.LayoutParams(
            handleSize,
            handleSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = boxX + boxW - handleSize / 2
            y = boxY + boxH - handleSize / 2
        }

        setupBoxDragAndResize(box, boxParams, handle, handleParams, handleSize, density)
        windowManager.addView(box, boxParams)
        windowManager.addView(handle, handleParams)
        roiBoxView = box
        roiBoxParams = boxParams
        resizeHandleView = handle
        resizeHandleParams = handleParams

        // 3. Floating Control Bar + Stats
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * density).toInt(), (6 * density).toInt(), (12 * density).toInt(), (6 * density).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 24 * density
                setColor(Color.parseColor("#EB0F172A"))
                setStroke((1 * density).toInt(), Color.parseColor("#475569"))
            }
        }

        val stats = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(0, 0, (8 * density).toInt(), 0)
        }

        val playBtn = Button(this).apply {
            text = "▶"
            textSize = 15f
            setTextColor(Color.parseColor("#10B981"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                if (isRunning) stopScanning(null) else startScanning()
            }
        }

        val closeBtn = Button(this).apply {
            text = "✕"
            textSize = 15f
            setTextColor(Color.parseColor("#FB7185"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                hideOverlay()
            }
        }

        bar.addView(stats)
        bar.addView(playBtn)
        bar.addView(closeBtn)

        val barParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (20 * density).toInt()
            y = (76 * density).toInt()
        }

        makeDraggable(bar, barParams)
        windowManager.addView(bar, barParams)
        controlBarView = bar
        tvStats = stats
        btnPlayPause = playBtn
        updateStatsText()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupBoxDragAndResize(
        box: View,
        boxParams: WindowManager.LayoutParams,
        handle: View,
        handleParams: WindowManager.LayoutParams,
        handleSize: Int,
        density: Float
    ) {
        val minW = (100 * density).toInt()
        val minH = (80 * density).toInt()
        val maxW = resources.displayMetrics.widthPixels
        val maxH = resources.displayMetrics.heightPixels

        var dragStartX = 0
        var dragStartY = 0
        var dragTouchX = 0f
        var dragTouchY = 0f

        box.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragStartX = boxParams.x
                    dragStartY = boxParams.y
                    dragTouchX = event.rawX
                    dragTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    boxParams.x = (dragStartX + (event.rawX - dragTouchX).toInt()).coerceIn(0, maxW - boxParams.width)
                    boxParams.y = (dragStartY + (event.rawY - dragTouchY).toInt()).coerceIn(0, maxH - boxParams.height)
                    handleParams.x = boxParams.x + boxParams.width - handleSize / 2
                    handleParams.y = boxParams.y + boxParams.height - handleSize / 2
                    windowManager.updateViewLayout(box, boxParams)
                    windowManager.updateViewLayout(handle, handleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    saveBoxBounds(boxParams)
                    true
                }
                else -> false
            }
        }

        var resStartW = 0
        var resStartH = 0
        var resTouchX = 0f
        var resTouchY = 0f

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    resStartW = boxParams.width
                    resStartH = boxParams.height
                    resTouchX = event.rawX
                    resTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val newW = (resStartW + (event.rawX - resTouchX).toInt()).coerceIn(minW, maxW - boxParams.x)
                    val newH = (resStartH + (event.rawY - resTouchY).toInt()).coerceIn(minH, maxH - boxParams.y)
                    boxParams.width = newW
                    boxParams.height = newH
                    handleParams.x = boxParams.x + newW - handleSize / 2
                    handleParams.y = boxParams.y + newH - handleSize / 2
                    windowManager.updateViewLayout(box, boxParams)
                    windowManager.updateViewLayout(handle, handleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    saveBoxBounds(boxParams)
                    true
                }
                else -> false
            }
        }
    }

    private fun saveBoxBounds(boxParams: WindowManager.LayoutParams) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putInt(KEY_BOX_X, boxParams.x)
            .putInt(KEY_BOX_Y, boxParams.y)
            .putInt(KEY_BOX_W, boxParams.width)
            .putInt(KEY_BOX_H, boxParams.height)
            .apply()
    }

    private fun setBoxInteractive(interactive: Boolean) {
        val box = roiBoxView ?: return
        val params = roiBoxParams ?: return
        params.flags = if (interactive) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        runCatching { windowManager.updateViewLayout(box, params) }
        resizeHandleView?.visibility = if (interactive) View.VISIBLE else View.GONE
    }

    fun hideOverlay() {
        stopScanning(null)
        roiBoxView?.let { runCatching { windowManager.removeView(it) } }
        resizeHandleView?.let { runCatching { windowManager.removeView(it) } }
        controlBarView?.let { runCatching { windowManager.removeView(it) } }
        roiBoxView = null
        roiBoxParams = null
        resizeHandleView = null
        resizeHandleParams = null
        controlBarView = null
        tvStats = null
        btnPlayPause = null
    }

    private fun startScanning() {
        if (ScreenCaptureService.instance == null) {
            Toast.makeText(this, "Avval ilovada Ekran tasviriga ruxsat bering", Toast.LENGTH_LONG).show()
            return
        }
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        currentMode = prefs.getString(KEY_MODE, MODE_HISTORY) ?: MODE_HISTORY
        targetCount = prefs.getInt(KEY_TARGET_COUNT, 1440)
        zebraThreshold = prefs.getInt(KEY_ZEBRA_THRESHOLD, 8)

        totalCounted = 0
        maxZebraFound = 0
        maxZebraRepeats = 0
        thresholdHits = 0
        streakCounts.clear()
        currentLiveZebra = 0
        alertSentForCurrentStreak = false
        updateStatsText()

        setBoxInteractive(false)
        isRunning = true
        btnPlayPause?.text = "⏸"
        btnPlayPause?.setTextColor(Color.parseColor("#FBBF24"))
        handler.post(loopRunnable)
    }

    private fun stopScanning(message: String?) {
        isRunning = false
        handler.removeCallbacks(loopRunnable)
        setBoxInteractive(true)
        btnPlayPause?.text = "▶"
        btnPlayPause?.setTextColor(Color.parseColor("#10B981"))
        if (message != null) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun updateStatsText() {
        if (currentMode == MODE_HISTORY) {
            tvStats?.text = "Tarix: $totalCounted/$targetCount | Max Zebra: $maxZebraFound (${maxZebraRepeats}x)"
        } else {
            tvStats?.text = "Real: Zebra $currentLiveZebra/$zebraThreshold | Max: $maxZebraFound"
        }
    }

    private fun performBackwardSwipe(roi: Rect) {
        val startX = roi.left + roi.width() * 0.12f
        val endX = roi.left + roi.width() * 0.88f
        val y = roi.centerY().toFloat()

        val path = Path().apply {
            moveTo(startX, y)
            lineTo(endX, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 450L))
            .build()
        dispatchGesture(gesture, null, null)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }
}
