package uz.avazbek.candlescanner

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvAccessStatus: TextView
    private lateinit var tvCaptureStatus: TextView
    private lateinit var rgMode: RadioGroup
    private lateinit var rbHistoryMode: RadioButton
    private lateinit var rbRealtimeMode: RadioButton
    private lateinit var etTargetCount: EditText
    private lateinit var etZebraThreshold: EditText
    private lateinit var etDelayMs: EditText
    private lateinit var etBotToken: EditText
    private lateinit var etChatId: EditText
    private lateinit var tabSettings: Button
    private lateinit var tabResults: Button
    private lateinit var layoutSettingsTab: LinearLayout
    private lateinit var layoutResultsTab: LinearLayout
    private lateinit var resultsListContainer: LinearLayout

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, intent)
            Toast.makeText(this, "Ekran tasviri tayyor!", Toast.LENGTH_SHORT).show()
            updateStatusTexts()
        } else {
            Toast.makeText(this, "Ruxsat berilmadi", Toast.LENGTH_SHORT).show()
        }
    }

    private val notificationPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            requestMediaProjection()
        } else {
            Toast.makeText(this, "Bildirishnoma ruxsati kerak", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvAccessStatus = findViewById(R.id.tvAccessStatus)
        tvCaptureStatus = findViewById(R.id.tvCaptureStatus)
        rgMode = findViewById(R.id.rgMode)
        rbHistoryMode = findViewById(R.id.rbHistoryMode)
        rbRealtimeMode = findViewById(R.id.rbRealtimeMode)
        etTargetCount = findViewById(R.id.etTargetCount)
        etZebraThreshold = findViewById(R.id.etZebraThreshold)
        etDelayMs = findViewById(R.id.etDelayMs)
        etBotToken = findViewById(R.id.etBotToken)
        etChatId = findViewById(R.id.etChatId)
        tabSettings = findViewById(R.id.tabSettings)
        tabResults = findViewById(R.id.tabResults)
        layoutSettingsTab = findViewById(R.id.layoutSettingsTab)
        layoutResultsTab = findViewById(R.id.layoutResultsTab)
        resultsListContainer = findViewById(R.id.resultsListContainer)

        tabSettings.setOnClickListener { showTab(isResults = false) }
        tabResults.setOnClickListener { showTab(isResults = true) }

        val prefs = getSharedPreferences(AutoSwipeAccessibilityService.PREFS_NAME, Context.MODE_PRIVATE)
        val savedMode = prefs.getString(AutoSwipeAccessibilityService.KEY_MODE, AutoSwipeAccessibilityService.MODE_HISTORY)
        if (savedMode == AutoSwipeAccessibilityService.MODE_REALTIME) {
            rbRealtimeMode.isChecked = true
        } else {
            rbHistoryMode.isChecked = true
        }

        etTargetCount.setText(prefs.getInt(AutoSwipeAccessibilityService.KEY_TARGET_COUNT, 1440).toString())
        etZebraThreshold.setText(prefs.getInt(AutoSwipeAccessibilityService.KEY_ZEBRA_THRESHOLD, 8).toString())
        etDelayMs.setText(prefs.getLong(AutoSwipeAccessibilityService.KEY_SWIPE_DELAY_MS, 1000L).toString())
        etBotToken.setText(prefs.getString(AutoSwipeAccessibilityService.KEY_BOT_TOKEN, ""))
        etChatId.setText(prefs.getString(AutoSwipeAccessibilityService.KEY_CHAT_ID, ""))

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnScreenCapture).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                requestMediaProjection()
            }
        }

        findViewById<Button>(R.id.btn1Day).setOnClickListener { etTargetCount.setText("1440") }
        findViewById<Button>(R.id.btn2Days).setOnClickListener { etTargetCount.setText("2880") }
        findViewById<Button>(R.id.btn10Days).setOnClickListener { etTargetCount.setText("14400") }

        findViewById<Button>(R.id.btnTestTelegram).setOnClickListener {
            saveAllSettings(showToast = false)
            TelegramNotifier.sendMessage(
                etBotToken.text.toString(),
                etChatId.text.toString(),
                "✅ Taxlil 2 (Zebra) Telegram bilan muvaffaqiyatli ulandi!"
            ) { _, msg ->
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnSaveSettings).setOnClickListener {
            saveAllSettings(showToast = true)
        }

        findViewById<Button>(R.id.btnShowOverlay).setOnClickListener {
            saveAllSettings(showToast = false)
            val service = AutoSwipeAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Avval Maxsus imkoniyatlar ruxsatini yoqing", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                service.showOverlay()
            }
        }

        findViewById<Button>(R.id.btnHideOverlay).setOnClickListener {
            AutoSwipeAccessibilityService.instance?.hideOverlay()
        }

        findViewById<Button>(R.id.btnClearResults).setOnClickListener {
            prefs.edit().remove(AutoSwipeAccessibilityService.KEY_SAVED_RESULTS).apply()
            updateAnalysisResultsText()
            Toast.makeText(this, "Natijalar tozalandi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveAllSettings(showToast: Boolean) {
        val prefs = getSharedPreferences(AutoSwipeAccessibilityService.PREFS_NAME, Context.MODE_PRIVATE)
        val mode = if (rbRealtimeMode.isChecked) {
            AutoSwipeAccessibilityService.MODE_REALTIME
        } else {
            AutoSwipeAccessibilityService.MODE_HISTORY
        }
        val count = (etTargetCount.text.toString().trim().toIntOrNull() ?: 1440).coerceIn(10, 50000)
        val zebraThreshold = (etZebraThreshold.text.toString().trim().toIntOrNull() ?: 8).coerceIn(2, 50)
        val delay = (etDelayMs.text.toString().trim().toLongOrNull() ?: 1000L).coerceAtLeast(300L)

        etTargetCount.setText(count.toString())
        etZebraThreshold.setText(zebraThreshold.toString())
        etDelayMs.setText(delay.toString())

        prefs.edit()
            .putString(AutoSwipeAccessibilityService.KEY_MODE, mode)
            .putInt(AutoSwipeAccessibilityService.KEY_TARGET_COUNT, count)
            .putInt(AutoSwipeAccessibilityService.KEY_ZEBRA_THRESHOLD, zebraThreshold)
            .putLong(AutoSwipeAccessibilityService.KEY_SWIPE_DELAY_MS, delay)
            .putString(AutoSwipeAccessibilityService.KEY_BOT_TOKEN, etBotToken.text.toString().trim())
            .putString(AutoSwipeAccessibilityService.KEY_CHAT_ID, etChatId.text.toString().trim())
            .apply()

        if (showToast) {
            Toast.makeText(this, "Saqlandi!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusTexts()
        updateAnalysisResultsText()
    }

    private fun showTab(isResults: Boolean) {
        if (isResults) {
            layoutSettingsTab.visibility = android.view.View.GONE
            layoutResultsTab.visibility = android.view.View.VISIBLE
            tabResults.setBackgroundColor(Color.parseColor("#10B981"))
            tabResults.setTextColor(Color.parseColor("#020617"))
            tabSettings.setBackgroundColor(Color.parseColor("#334155"))
            tabSettings.setTextColor(Color.parseColor("#F8FAFC"))
        } else {
            layoutSettingsTab.visibility = android.view.View.VISIBLE
            layoutResultsTab.visibility = android.view.View.GONE
            tabSettings.setBackgroundColor(Color.parseColor("#10B981"))
            tabSettings.setTextColor(Color.parseColor("#020617"))
            tabResults.setBackgroundColor(Color.parseColor("#334155"))
            tabResults.setTextColor(Color.parseColor("#F8FAFC"))
        }
    }

    private fun updateAnalysisResultsText() {
        val prefs = getSharedPreferences(AutoSwipeAccessibilityService.PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(AutoSwipeAccessibilityService.KEY_SAVED_RESULTS, "[]") ?: "[]"
        val arr = try { JSONArray(rawJson) } catch (e: Exception) { JSONArray() }
        tabResults.text = "Natijalar (${arr.length()})"
        resultsListContainer.removeAllViews()

        if (arr.length() == 0) {
            val emptyTv = TextView(this).apply {
                text = "Hozircha tahlil natijalari yo'q. Tarix tahlilini ishga tushiring."
                setTextColor(Color.parseColor("#94A3B8"))
                textSize = 13f
                setPadding(12, 24, 12, 24)
            }
            resultsListContainer.addView(emptyTv)
            return
        }

        val density = resources.displayMetrics.density
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val time = obj.optString("time", "")
            val total = obj.optInt("total", 0)
            val maxZ = obj.optInt("maxZebra", 0)
            val breakdown = obj.optJSONObject("breakdown")

            val card = MaterialCardView(this).apply {
                setCardBackgroundColor(Color.parseColor("#1E293B"))
                radius = 14 * density
                strokeColor = Color.parseColor("#334155")
                strokeWidth = (1 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (10 * density).toInt() }
            }

            val inner = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val p = (14 * density).toInt()
                setPadding(p, p, p, p)
            }

            val titleTv = TextView(this).apply {
                text = "#${i + 1}  •  $time  •  $total ta svecha"
                setTextColor(Color.parseColor("#34D399"))
                textSize = 14f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val maxTv = TextView(this).apply {
                text = "Eng katta Zebra: $maxZ ta"
                setTextColor(Color.parseColor("#F8FAFC"))
                textSize = 13f
                setPadding(0, (4 * density).toInt(), 0, (6 * density).toInt())
            }

            val lines = StringBuilder()
            if (maxZ < 5 || breakdown == null) {
                lines.append("5 talik va undan katta Zebra uchramadi.")
            } else {
                for (len in 5..maxZ) {
                    val cnt = breakdown.optInt(len.toString(), 0)
                    lines.append("${len} talik zebradan keyin buzildi: $cnt marta
")
                }
            }

            val detailTv = TextView(this).apply {
                text = lines.toString().trim()
                setTextColor(Color.parseColor("#CBD5E1"))
                textSize = 13f
            }

            inner.addView(titleTv)
            inner.addView(maxTv)
            inner.addView(detailTv)
            card.addView(inner)
            resultsListContainer.addView(card)
        }
    }

    private fun requestMediaProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun updateStatusTexts() {
        if (AutoSwipeAccessibilityService.instance != null) {
            tvAccessStatus.text = "Maxsus imkoniyatlar: Yoqilgan"
            tvAccessStatus.setTextColor(Color.parseColor("#34D399"))
        } else {
            tvAccessStatus.text = "Maxsus imkoniyatlar: O'chirilgan"
            tvAccessStatus.setTextColor(Color.parseColor("#FB7185"))
        }

        if (ScreenCaptureService.instance != null) {
            tvCaptureStatus.text = "Ekran tasviri: Tayyor"
            tvCaptureStatus.setTextColor(Color.parseColor("#34D399"))
        } else {
            tvCaptureStatus.text = "Ekran tasviri: Ruxsat berilmagan"
            tvCaptureStatus.setTextColor(Color.parseColor("#FB7185"))
        }
    }
}
