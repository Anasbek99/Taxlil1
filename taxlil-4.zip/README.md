# Taxlil 2 — Zebra (Pocket Option uchun Android loyiha)

Ikkita asosiy rejim:
1. **Tarix tahlili:** Grafikni orqaga surib, belgilangan svecha soni ichida eng katta Zebra (rang almashish) seriyasini va necha marta takrorlanganini aniqlaydi.
2. **Real vaqtda kuzatuv:** Jonli grafikda ketma-ket rang almashishlar soni siz belgilagan chegaraga yetganda, Telegram bot orqali asosiy telefoningizga xabar yuboradi.
