package uz.avazbek.candlescanner

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object TelegramNotifier {

    fun sendMessage(
        botToken: String,
        chatId: String,
        message: String,
        onResult: ((Boolean, String) -> Unit)? = null
    ) {
        val cleanToken = botToken.trim()
        val cleanChatId = chatId.trim()
        if (cleanToken.isEmpty() || cleanChatId.isEmpty()) {
            onResult?.let { cb ->
                Handler(Looper.getMainLooper()).post { cb(false, "Token yoki Chat ID bo'sh") }
            }
            return
        }

        Thread {
            try {
                val url = URL("https://api.telegram.org/bot$cleanToken/sendMessage")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 8000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }

                val payload = JSONObject().apply {
                    put("chat_id", cleanChatId)
                    put("text", message)
                }.toString()

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(payload)
                    writer.flush()
                }

                val code = conn.responseCode
                conn.disconnect()
                val ok = code in 200..299
                val info = if (ok) "Telegram xabar yuborildi!" else "Telegram xato: HTTP $code"
                onResult?.let { cb ->
                    Handler(Looper.getMainLooper()).post { cb(ok, info) }
                }
            } catch (e: Exception) {
                onResult?.let { cb ->
                    Handler(Looper.getMainLooper()).post { cb(false, "Ulanish xatosi: ${e.message}") }
                }
            }
        }.start()
    }
}
