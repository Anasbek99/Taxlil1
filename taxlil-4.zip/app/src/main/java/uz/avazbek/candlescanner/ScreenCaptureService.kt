package uz.avazbek.candlescanner

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "candle_scanner_channel"
        private const val NOTIF_ID = 101

        var instance: ScreenCaptureService? = null
            private set
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var screenWidth = 1080
    private var screenHeight = 1920
    private var screenDensity = 320

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        val metrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }

        if (resultCode == Activity.RESULT_OK && data != null) {
            setupProjection(resultCode, data)
        }
        return START_NOT_STICKY
    }

    private fun setupProjection(resultCode: Int, data: Intent) {
        cleanupProjection()
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mpm.getMediaProjection(resultCode, data) ?: return
        mediaProjection = projection

        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                cleanupProjection()
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        virtualDisplay = projection.createVirtualDisplay(
            "CandleScannerDisplay",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            null
        )
    }

    /**
     * Returns ordered list of candle colors from left to right inside [roi]:
     * 1 = Green (Bullish), 2 = Red (Bearish).
     */
    fun detectCandleSequence(roi: Rect): List<Int> {
        val reader = imageReader ?: return emptyList()
        val image = reader.acquireLatestImage() ?: return emptyList()

        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride

            val left = (roi.left + 8).coerceIn(0, image.width - 1)
            val right = (roi.right - 8).coerceIn(left + 1, image.width)
            val top = (roi.top + 8).coerceIn(0, image.height - 1)
            val bottom = (roi.bottom - 8).coerceIn(top + 1, image.height)

            val candles = mutableListOf<Int>()
            var activeType = 0 // 0=none, 1=green, 2=red
            var activeWidth = 0

            val stepX = 2
            val stepY = 2

            var x = left
            while (x < right) {
                var greenPixels = 0
                var redPixels = 0

                var y = top
                while (y < bottom) {
                    val offset = y * rowStride + x * pixelStride
                    val r = buffer.get(offset).toInt() and 0xFF
                    val g = buffer.get(offset + 1).toInt() and 0xFF
                    val b = buffer.get(offset + 2).toInt() and 0xFF

                    if (g > 110 && g > r + 35 && g > b + 20) {
                        greenPixels++
                    } else if (r > 120 && r > g + 40 && r > b + 25) {
                        redPixels++
                    }
                    y += stepY
                }

                val colType = when {
                    greenPixels >= 2 && greenPixels > redPixels -> 1
                    redPixels >= 2 && redPixels > greenPixels -> 2
                    else -> 0
                }

                if (colType != 0 && colType == activeType) {
                    activeWidth++
                } else {
                    if (activeType != 0 && activeWidth >= 1) {
                        candles.add(activeType)
                    }
                    activeType = colType
                    activeWidth = if (colType != 0) 1 else 0
                }

                x += stepX
            }

            if (activeType != 0 && activeWidth >= 1) {
                candles.add(activeType)
            }

            return candles
        } finally {
            image.close()
        }
    }

    private fun cleanupProjection() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
    }

    override fun onDestroy() {
        super.onDestroy()
        cleanupProjection()
        if (instance == this) instance = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Taxlil 2",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Taxlil 2 faol")
            .setContentText("Zebra tahlili uchun ekran kuzatuvda")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
    }
}
